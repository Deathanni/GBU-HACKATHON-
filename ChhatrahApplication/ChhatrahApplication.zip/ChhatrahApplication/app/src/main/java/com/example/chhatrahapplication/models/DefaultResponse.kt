package com.example.chhatrahapplication.models

data class DefaultResponse (
    val roll_no: String,
    val password: String,
    val name:String,
    val hostel_code: String
)