package com.example.chhatrahapplication.models

data class LoginResponse(
    val token: String
)