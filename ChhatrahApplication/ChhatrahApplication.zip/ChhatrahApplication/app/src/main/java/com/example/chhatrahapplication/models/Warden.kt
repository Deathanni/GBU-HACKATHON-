package com.example.chhatrahapplication.models

data class Warden(
    val token: String,
    val username: String,
    val password:String
)