package com.example.chhatrahapplication.models

class WardenLoginResponse {
}